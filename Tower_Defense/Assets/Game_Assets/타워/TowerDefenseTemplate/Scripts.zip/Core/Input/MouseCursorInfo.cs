﻿namespace Core.Input
{
	class MouseCursorInfo : PointerInfo
	{
	}
}