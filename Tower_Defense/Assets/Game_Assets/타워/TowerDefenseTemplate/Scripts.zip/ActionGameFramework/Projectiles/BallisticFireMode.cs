namespace ActionGameFramework.Projectiles
{
	public enum BallisticFireMode
	{
		UseLaunchSpeed,
		UseLaunchAngle
	}
}